<?php

$routes->get('/', 'Pages::index');
$routes->get('/profil', 'Pages::profil');
$routes->get('/kontak', 'Pages::kontak');
