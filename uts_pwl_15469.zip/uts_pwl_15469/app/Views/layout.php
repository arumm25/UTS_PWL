<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title><?= $title ?? 'Sekolah Perempuan PERMATA, Kota Semarang' ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Link ke Bootstrap dan Tailwind CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

  <style>
    /* Menambahkan style untuk memastikan konten utama tidak tertutup sidebar */
    body {
      margin: 0;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 250px; /* Lebar sidebar */
      height: 100vh; /* Agar sidebar sepanjang tinggi layar */
      background-color: #f8f9fa; /* Warna background sidebar */
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1); /* Shadow untuk sidebar */
    }

    .content {
      margin-left: 250px; /* Memberikan margin kiri untuk konten utama agar tidak tertutup sidebar */
      padding: 20px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <?= view('components/sidebar') ?> <!-- Sidebar kamu -->
  </div>

  <!-- Konten Utama -->
  <div class="content">
    <?= $this->renderSection('content') ?> <!-- Bagian ini akan diisi dengan konten halaman -->
  </div>

</body>
</html>
