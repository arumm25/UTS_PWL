<footer class="bg-dark text-white text-center py-3">
  <p>&copy; 2025 Sekolah Perempuan PERMATA. Kota Semarang</p>
</footer>
