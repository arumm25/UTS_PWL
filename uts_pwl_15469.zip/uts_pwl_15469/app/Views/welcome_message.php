<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Web Profile</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li class="menu-item"><a href="#">Home</a></li>
        <li class="menu-item"><a href="#">About</a></li>
        <li class="menu-item"><a href="#">Services</a></li>
        <li class="menu-item"><a href="#">Contact</a></li>
      </ul>
      <div class="menu-toggle">
        <button>Menu</button>
      </div>
    </nav>
  </header>

  <section>
    <h1>Selamat Datang di Web Profile</h1>
    <p>Ini adalah contoh sederhana dari web profile.</p>
    <a href="#">Selengkapnya</a>
  </section>

  <footer>
    <p>&copy; 2025 Web Profile. All rights reserved.</p>
  </footer>
</body>
</html>
