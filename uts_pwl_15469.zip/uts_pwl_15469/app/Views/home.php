<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>Selamat Datang di Website Resmi Sekolah Perempuan PERMATA</h2>
<p>Sekolah Perempuan PERMATA Samarang  adalah sekolah unggulan yang berkomitmen mencetak generasi berprestasi dan berkarakter.</p>
<img src="https://i0.wp.com/www.maxmanroe.com/vid/wp-content/uploads/2018/09/Pengertian-Sekolah.jpg?fit=700%2C350&ssl=1" class="img-fluid rounded" alt="Sekolah">
<?= $this->endSection() ?>
