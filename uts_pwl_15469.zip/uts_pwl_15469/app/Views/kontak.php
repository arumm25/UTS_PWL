<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>Kontak Kami</h2>
<p>Alamat: Jl. Nogosaren No. 123, KotaSamarang<br>
Email: info@PERMATA.sch.id<br>
Telp: (024) 123-4889</p>
<iframe src="https://maps.google.com/maps?q=semarang&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="250" style="border:0;" allowfullscreen></iframe>
<?= $this->endSection() ?>
