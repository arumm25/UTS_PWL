<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>Profil Sekolah</h2>
<p>Sekolah Perempuan PERMATA Samarang berdiri sejak tahun 1990 dan telah meluluskan ribuan siswa berprestasi. Kurikulum yang diterapkan berfokus pada pelatihan dan pemasaran.</p>
<ul>
  <li>Akreditasi A</li>
  <li>Fasilitas lengkap: Laborat, Perpustakaan Digital, Lapangan Olahraga</li>
  <li>Program Unggulan: Kelas Olimpiade, Program Class Marketplace, Green School</li>
</ul>
<?= $this->endSection() ?>
